#ifndef TASK_1_H_
#define TASK_1_H_

#include <stdio.h>

void task1(void);

#endif // TASK_1_H_